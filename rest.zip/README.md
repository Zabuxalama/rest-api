## Rest api WhatsApp bot
`Created by: Danzz Coding`

### Example
 [`Rest Api`](https://api-danzz.xyz)<br>

### Information
Language
`html, css, js`

Manufacture date
`30 september 2022`

### Forks
 [`Repo`](https://github.com/Danzzxcodes/danzz-apii/fork)<br>

### Deploy to heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/)

### Settings 
File Setting [`set.js`](https://github.com/Danzzxcodes/danzz-apii/edit/master/set.js)<br>

### Feature list

| Feature Active |✔|
| ------------- | ------------- |
| Downloader |✔️|
| Asupan  |✔️|
| Cecan  |✔️|
| Search  |✔️|
| Film  |✔️|
| Text Pro  |✔️|
| Photo Oxy  |✔️|
| Canvas  |✔️|
| Maker  |✔️|
| Game  |✔️|
| Sfw  |✔️|
| Nsfw  |✔️|
| Simi  |✔️|
| Random  |✔️|
| Stalker |✔️|
| Short Link  |✔️|
| Trending  |✔️|
| Islamic  |✔️|
| Information  |✔️|
| News  |✔️|
| Primbon  |✔️|
| Tools  |✔️|
| Other  |✔️|

### Sosmed

[`Instagram`](https://instagram.com/ramdani_real01)<br>
[`Youtube`](https://youtube.com/c/DanzzCoding)<br>

### Contact

[`WhatsApp`](https://wa.me/6288296339947)<br>
[`Email`](mailto:danzzcoding@gmail.com)<br>
[`My Rest Api`](https://danzz-api.herokuapp.com)<br>
